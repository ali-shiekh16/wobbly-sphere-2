import { Leva } from 'leva';

const LevaWrapper = () => {
  return <Leva collapsed={false} />;
};

export default LevaWrapper;
